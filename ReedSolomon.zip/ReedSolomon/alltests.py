import unittest

from rstest import *
from polynomialtest import *
from fftest import *

unittest.main()
